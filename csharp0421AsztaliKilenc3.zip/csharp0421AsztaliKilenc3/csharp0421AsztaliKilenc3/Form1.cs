﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace csharp0421AsztaliKilenc3
{
    public partial class Form1 : Form
    {
        
        
        int pont = 0;
        
        string szoveg = ""; //innen szerzünk értékeket?
        int i = 1; int a = 400; int b = 400; int c = 100; int d = 100;

        

        public Form1()
        {
            InitializeComponent();
            panelVisible(1);


            
            //areaButton10.BackgroundImage = Properties.Resources.NyílK; areaButton10.BackgroundImageLayout = ImageLayout.Stretch;
            

            
            
            richTextBox1.Visible = false;
            labelButton1.Text = $"Pénz: {pont}"; richTextBoxResponse.Text = "Hello. Írd be, hogy 'Parancsok?', ha nem tudod, mi van.";
            labelTextBox1.Text = "Legutóbbi gondolat..."; labelRichTextBox1.Text = "Legutóbbi összetett gondolat...";

            


        }

        private void button1_Click(object sender, EventArgs e)
        {
            pont += 1;
            labelButton1.Text = $"Pénz: {pont}";
            
            

            

            //panelVisible(2);

        }

        private void textbox1_TextChanged(object sender, EventArgs e)
        {
            

        
        }


        //public void hatterkep(string nev, System.Drawing.Bitmap kepnev)
        

        public void panelVisible(int sorszam)
        {
            // Ha új panelt raksz be, ezt növelni kell 1-gyel
            if (sorszam == 0) { for (int i = 1; i < 5; i++) this.Controls["aPanel" + i].Visible = false; aPanel0.Visible = true; aPanelInfo.Visible = true; }
            else
            {
                for (int i = 1; i < 5; i++) this.Controls["aPanel" + i].Visible = false; aPanelInfo.Visible = true;
                if (sorszam < 10) this.Controls["aPanel" + sorszam].Visible = true; aPanel0.Visible = true; aPanel0.BringToFront();
            }

        }

        public void createButton(int lx, int ly, int sx, int sy, string name)
        {

            Button newButton = new Button(); newButton.Text = "asd"; newButton.Name = name; newButton.BackColor = Color.Black;
            newButton.CreateControl(); newButton.ForeColor = Color.White;
            newButton.Location = new Point(lx, ly); newButton.Size = new Size(sx, sy); newButton.BringToFront();
            this.Controls.Add(newButton);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            panelVisible(1);
        }

        private void richTextBoxResponse_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            string szoveg = textBox1.Text.ToLower(); string nagyszoveg = labelRichTextBox1.Text.ToLower();

            if (szoveg.Contains("."))
            {
                richTextBox1.Text += textBox1.Text; labelRichTextBox1.Text = richTextBox1.Text; richTextBox1.Text = "";
                labelTextBox1.Text = textBox1.Text; textBox1.Text = ""; nagyszoveg = labelRichTextBox1.Text.ToLower();
                switch (szoveg)
                {
                    case "béla.":
                        switch (pont)
                        {
                            case 100: richTextBoxResponse.Text = "nincs jól"; break;
                            case 1: richTextBoxResponse.Text = "jól van"; break;
                        }
                        break;

                    default:
                        break;
                }
                if (nagyszoveg.Contains("close") || nagyszoveg.Contains("close.")) aPanelInfo.Visible = false;
                if (nagyszoveg.Contains("info") || nagyszoveg.Contains("info.")) aPanelInfo.Visible = true;

            }
            if (szoveg.Contains("+"))
            {
                textBox1.Text = textBox1.Text.Remove(textBox1.Text.Length - 1);
                labelTextBox1.Text = textBox1.Text; richTextBox1.Text += textBox1.Text;
                textBox1.Text = ""; richTextBox1.Text += Environment.NewLine;

            }

            if (textBox1.Text.Contains("?")) //switch?
            {
                
                if (szoveg.Contains("béla") || szoveg.Contains("bélu")
                    || szoveg.Contains("bélá"))
                {
                    richTextBoxResponse.Text = "Biztosan a Béláról kérdeztél, most éppen vásárolni van."; textBox1.Text = "";
                }
                if (szoveg.Contains("parancsok"))
                {
                    richTextBoxResponse.Text = "Azt még én sem tudom, mi van."; textBox1.Text = "";
                    richTextBoxDescription.Text =
@"Írd be, hogy 'Történet?', ha tudni akarod, hogy mi van.
Írj be valamit, hátha elindul miatta valami.";
                }

            }

            if (textBox1.Text == "send!") { } // txt-be írás
            if (textBox1.Text == "4") { richTextBoxResponse.Text = "Helyes válasz!"; textBox1.Text = "0"; }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {

            
            i++; a += c + 10; if (a > 600) { b += d + 10; a = 100; }
            
            aPanelInfo.Visible = true; labelTerrain.Text = "Terület: Síkság"; labelValue.Text = "Érték: 5000 Ft";

            if (i > 5) { aPanel1.Visible = false; aPanel2.Visible = false; aPanel3.Visible = false; aPanel4.Visible = false; aPanelInfo.Visible = true; }


        }

        private void button3_Click(object sender, EventArgs e)
        {
            int panel = int.Parse(textBox2.Text); panelVisible(panel);
        }

        private void aPanel1_VisibleChanged(object sender, EventArgs e)
        {
            /*if (aPanel1.Visible = true)
            {
                createButton(200, 300, 100, 50);
            }*/
        }
    }
}

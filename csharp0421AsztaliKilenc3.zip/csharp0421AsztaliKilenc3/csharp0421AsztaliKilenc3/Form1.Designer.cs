﻿
namespace csharp0421AsztaliKilenc3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.aPanel1 = new System.Windows.Forms.Panel();
            this.labelTextBox1 = new System.Windows.Forms.RichTextBox();
            this.labelRichTextBox1 = new System.Windows.Forms.RichTextBox();
            this.buttonNyugat = new System.Windows.Forms.Button();
            this.buttonDel = new System.Windows.Forms.Button();
            this.buttonEszak = new System.Windows.Forms.Button();
            this.buttonKelet = new System.Windows.Forms.Button();
            this.areaButton8 = new System.Windows.Forms.Button();
            this.areaButton7 = new System.Windows.Forms.Button();
            this.areaButton6 = new System.Windows.Forms.Button();
            this.areaButton5 = new System.Windows.Forms.Button();
            this.areaButton25 = new System.Windows.Forms.Button();
            this.areaButton24 = new System.Windows.Forms.Button();
            this.areaButton23 = new System.Windows.Forms.Button();
            this.areaButton22 = new System.Windows.Forms.Button();
            this.areaButton21 = new System.Windows.Forms.Button();
            this.areaButton20 = new System.Windows.Forms.Button();
            this.areaButton19 = new System.Windows.Forms.Button();
            this.areaButton18 = new System.Windows.Forms.Button();
            this.areaButton17 = new System.Windows.Forms.Button();
            this.areaButton16 = new System.Windows.Forms.Button();
            this.areaButton15 = new System.Windows.Forms.Button();
            this.areaButton14 = new System.Windows.Forms.Button();
            this.areaButton13 = new System.Windows.Forms.Button();
            this.areaButton12 = new System.Windows.Forms.Button();
            this.areaButton11 = new System.Windows.Forms.Button();
            this.areaButton10 = new System.Windows.Forms.Button();
            this.areaButton9 = new System.Windows.Forms.Button();
            this.areaButton1x3 = new System.Windows.Forms.Button();
            this.areaButton4 = new System.Windows.Forms.Button();
            this.areaButton1x2 = new System.Windows.Forms.Button();
            this.areaButton1x1 = new System.Windows.Forms.Button();
            this.richTextBoxDescription = new System.Windows.Forms.RichTextBox();
            this.labelButton1 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.labelValue = new System.Windows.Forms.Label();
            this.labelTerrain = new System.Windows.Forms.Label();
            this.richTextBoxResponse = new System.Windows.Forms.RichTextBox();
            this.aPanel2 = new System.Windows.Forms.Panel();
            this.aPanel3 = new System.Windows.Forms.Panel();
            this.aPanel4 = new System.Windows.Forms.Panel();
            this.aPanel0 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.aPanelInfo = new System.Windows.Forms.Panel();
            this.aPanel1.SuspendLayout();
            this.aPanel0.SuspendLayout();
            this.aPanelInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(373, 73);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(94, 29);
            this.button1.TabIndex = 1;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(871, 489);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(177, 53);
            this.richTextBox1.TabIndex = 2;
            this.richTextBox1.Text = "";
            // 
            // aPanel1
            // 
            this.aPanel1.BackColor = System.Drawing.Color.Gainsboro;
            this.aPanel1.Controls.Add(this.labelTextBox1);
            this.aPanel1.Controls.Add(this.labelRichTextBox1);
            this.aPanel1.Controls.Add(this.buttonNyugat);
            this.aPanel1.Controls.Add(this.buttonDel);
            this.aPanel1.Controls.Add(this.buttonEszak);
            this.aPanel1.Controls.Add(this.buttonKelet);
            this.aPanel1.Controls.Add(this.areaButton8);
            this.aPanel1.Controls.Add(this.areaButton7);
            this.aPanel1.Controls.Add(this.areaButton6);
            this.aPanel1.Controls.Add(this.areaButton5);
            this.aPanel1.Controls.Add(this.areaButton25);
            this.aPanel1.Controls.Add(this.areaButton24);
            this.aPanel1.Controls.Add(this.areaButton23);
            this.aPanel1.Controls.Add(this.areaButton22);
            this.aPanel1.Controls.Add(this.areaButton21);
            this.aPanel1.Controls.Add(this.areaButton20);
            this.aPanel1.Controls.Add(this.areaButton19);
            this.aPanel1.Controls.Add(this.areaButton18);
            this.aPanel1.Controls.Add(this.areaButton17);
            this.aPanel1.Controls.Add(this.areaButton16);
            this.aPanel1.Controls.Add(this.areaButton15);
            this.aPanel1.Controls.Add(this.areaButton14);
            this.aPanel1.Controls.Add(this.areaButton13);
            this.aPanel1.Controls.Add(this.areaButton12);
            this.aPanel1.Controls.Add(this.areaButton11);
            this.aPanel1.Controls.Add(this.areaButton10);
            this.aPanel1.Controls.Add(this.areaButton9);
            this.aPanel1.Controls.Add(this.areaButton1x3);
            this.aPanel1.Controls.Add(this.areaButton4);
            this.aPanel1.Controls.Add(this.areaButton1x2);
            this.aPanel1.Controls.Add(this.areaButton1x1);
            this.aPanel1.Controls.Add(this.richTextBoxDescription);
            this.aPanel1.Controls.Add(this.labelButton1);
            this.aPanel1.Controls.Add(this.richTextBox1);
            this.aPanel1.Controls.Add(this.button1);
            this.aPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.aPanel1.Location = new System.Drawing.Point(0, 0);
            this.aPanel1.Name = "aPanel1";
            this.aPanel1.Size = new System.Drawing.Size(1051, 662);
            this.aPanel1.TabIndex = 1;
            this.aPanel1.VisibleChanged += new System.EventHandler(this.aPanel1_VisibleChanged);
            // 
            // labelTextBox1
            // 
            this.labelTextBox1.Location = new System.Drawing.Point(111, 188);
            this.labelTextBox1.Name = "labelTextBox1";
            this.labelTextBox1.Size = new System.Drawing.Size(217, 55);
            this.labelTextBox1.TabIndex = 15;
            this.labelTextBox1.Text = "labelTextBox1";
            // 
            // labelRichTextBox1
            // 
            this.labelRichTextBox1.Location = new System.Drawing.Point(23, 251);
            this.labelRichTextBox1.Name = "labelRichTextBox1";
            this.labelRichTextBox1.Size = new System.Drawing.Size(305, 60);
            this.labelRichTextBox1.TabIndex = 14;
            this.labelRichTextBox1.Text = "labelRichTextBox1";
            // 
            // buttonNyugat
            // 
            this.buttonNyugat.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.NyílNy;
            this.buttonNyugat.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonNyugat.Location = new System.Drawing.Point(23, 185);
            this.buttonNyugat.Name = "buttonNyugat";
            this.buttonNyugat.Size = new System.Drawing.Size(82, 58);
            this.buttonNyugat.TabIndex = 13;
            this.buttonNyugat.UseVisualStyleBackColor = true;
            // 
            // buttonDel
            // 
            this.buttonDel.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.NyílD;
            this.buttonDel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonDel.Location = new System.Drawing.Point(486, 612);
            this.buttonDel.Name = "buttonDel";
            this.buttonDel.Size = new System.Drawing.Size(65, 38);
            this.buttonDel.TabIndex = 12;
            this.buttonDel.UseVisualStyleBackColor = true;
            // 
            // buttonEszak
            // 
            this.buttonEszak.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.NyílÉ;
            this.buttonEszak.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonEszak.Location = new System.Drawing.Point(527, 16);
            this.buttonEszak.Name = "buttonEszak";
            this.buttonEszak.Size = new System.Drawing.Size(100, 72);
            this.buttonEszak.TabIndex = 11;
            this.buttonEszak.UseVisualStyleBackColor = true;
            // 
            // buttonKelet
            // 
            this.buttonKelet.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.NyílK;
            this.buttonKelet.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonKelet.Location = new System.Drawing.Point(877, 204);
            this.buttonKelet.Name = "buttonKelet";
            this.buttonKelet.Size = new System.Drawing.Size(106, 80);
            this.buttonKelet.TabIndex = 10;
            this.buttonKelet.UseVisualStyleBackColor = true;
            // 
            // areaButton8
            // 
            this.areaButton8.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.fekete;
            this.areaButton8.Location = new System.Drawing.Point(526, 264);
            this.areaButton8.Name = "areaButton8";
            this.areaButton8.Size = new System.Drawing.Size(80, 80);
            this.areaButton8.TabIndex = 9;
            this.areaButton8.Text = "button2";
            this.areaButton8.UseVisualStyleBackColor = true;
            this.areaButton8.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // areaButton7
            // 
            this.areaButton7.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.fekete;
            this.areaButton7.Location = new System.Drawing.Point(440, 264);
            this.areaButton7.Name = "areaButton7";
            this.areaButton7.Size = new System.Drawing.Size(80, 80);
            this.areaButton7.TabIndex = 9;
            this.areaButton7.Text = "button2";
            this.areaButton7.UseVisualStyleBackColor = true;
            this.areaButton7.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // areaButton6
            // 
            this.areaButton6.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.fekete;
            this.areaButton6.Location = new System.Drawing.Point(354, 264);
            this.areaButton6.Name = "areaButton6";
            this.areaButton6.Size = new System.Drawing.Size(80, 80);
            this.areaButton6.TabIndex = 9;
            this.areaButton6.Text = "button2";
            this.areaButton6.UseVisualStyleBackColor = true;
            this.areaButton6.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // areaButton5
            // 
            this.areaButton5.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.fekete;
            this.areaButton5.Location = new System.Drawing.Point(698, 178);
            this.areaButton5.Name = "areaButton5";
            this.areaButton5.Size = new System.Drawing.Size(80, 80);
            this.areaButton5.TabIndex = 9;
            this.areaButton5.Text = "button2";
            this.areaButton5.UseVisualStyleBackColor = true;
            this.areaButton5.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // areaButton25
            // 
            this.areaButton25.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.fekete;
            this.areaButton25.Location = new System.Drawing.Point(698, 522);
            this.areaButton25.Name = "areaButton25";
            this.areaButton25.Size = new System.Drawing.Size(80, 80);
            this.areaButton25.TabIndex = 9;
            this.areaButton25.Text = "button2";
            this.areaButton25.UseVisualStyleBackColor = true;
            this.areaButton25.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // areaButton24
            // 
            this.areaButton24.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.fekete;
            this.areaButton24.Location = new System.Drawing.Point(612, 522);
            this.areaButton24.Name = "areaButton24";
            this.areaButton24.Size = new System.Drawing.Size(80, 80);
            this.areaButton24.TabIndex = 9;
            this.areaButton24.Text = "button2";
            this.areaButton24.UseVisualStyleBackColor = true;
            this.areaButton24.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // areaButton23
            // 
            this.areaButton23.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.fekete;
            this.areaButton23.Location = new System.Drawing.Point(526, 522);
            this.areaButton23.Name = "areaButton23";
            this.areaButton23.Size = new System.Drawing.Size(80, 80);
            this.areaButton23.TabIndex = 9;
            this.areaButton23.Text = "button2";
            this.areaButton23.UseVisualStyleBackColor = true;
            this.areaButton23.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // areaButton22
            // 
            this.areaButton22.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.fekete;
            this.areaButton22.Location = new System.Drawing.Point(440, 522);
            this.areaButton22.Name = "areaButton22";
            this.areaButton22.Size = new System.Drawing.Size(80, 80);
            this.areaButton22.TabIndex = 9;
            this.areaButton22.Text = "button2";
            this.areaButton22.UseVisualStyleBackColor = true;
            this.areaButton22.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // areaButton21
            // 
            this.areaButton21.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.fekete;
            this.areaButton21.Location = new System.Drawing.Point(354, 522);
            this.areaButton21.Name = "areaButton21";
            this.areaButton21.Size = new System.Drawing.Size(80, 80);
            this.areaButton21.TabIndex = 9;
            this.areaButton21.Text = "button2";
            this.areaButton21.UseVisualStyleBackColor = true;
            this.areaButton21.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // areaButton20
            // 
            this.areaButton20.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.fekete;
            this.areaButton20.Location = new System.Drawing.Point(699, 436);
            this.areaButton20.Name = "areaButton20";
            this.areaButton20.Size = new System.Drawing.Size(80, 80);
            this.areaButton20.TabIndex = 9;
            this.areaButton20.Text = "button2";
            this.areaButton20.UseVisualStyleBackColor = true;
            this.areaButton20.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // areaButton19
            // 
            this.areaButton19.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.fekete;
            this.areaButton19.Location = new System.Drawing.Point(613, 436);
            this.areaButton19.Name = "areaButton19";
            this.areaButton19.Size = new System.Drawing.Size(80, 80);
            this.areaButton19.TabIndex = 9;
            this.areaButton19.Text = "button2";
            this.areaButton19.UseVisualStyleBackColor = true;
            this.areaButton19.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // areaButton18
            // 
            this.areaButton18.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.fekete;
            this.areaButton18.Location = new System.Drawing.Point(527, 436);
            this.areaButton18.Name = "areaButton18";
            this.areaButton18.Size = new System.Drawing.Size(80, 80);
            this.areaButton18.TabIndex = 9;
            this.areaButton18.Text = "button2";
            this.areaButton18.UseVisualStyleBackColor = true;
            this.areaButton18.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // areaButton17
            // 
            this.areaButton17.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.fekete;
            this.areaButton17.Location = new System.Drawing.Point(440, 436);
            this.areaButton17.Name = "areaButton17";
            this.areaButton17.Size = new System.Drawing.Size(80, 80);
            this.areaButton17.TabIndex = 9;
            this.areaButton17.Text = "button2";
            this.areaButton17.UseVisualStyleBackColor = true;
            this.areaButton17.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // areaButton16
            // 
            this.areaButton16.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.fekete;
            this.areaButton16.Location = new System.Drawing.Point(354, 436);
            this.areaButton16.Name = "areaButton16";
            this.areaButton16.Size = new System.Drawing.Size(80, 80);
            this.areaButton16.TabIndex = 9;
            this.areaButton16.Text = "button2";
            this.areaButton16.UseVisualStyleBackColor = true;
            this.areaButton16.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // areaButton15
            // 
            this.areaButton15.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.fekete;
            this.areaButton15.Location = new System.Drawing.Point(699, 350);
            this.areaButton15.Name = "areaButton15";
            this.areaButton15.Size = new System.Drawing.Size(80, 80);
            this.areaButton15.TabIndex = 9;
            this.areaButton15.Text = "button2";
            this.areaButton15.UseVisualStyleBackColor = true;
            this.areaButton15.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // areaButton14
            // 
            this.areaButton14.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.fekete;
            this.areaButton14.Location = new System.Drawing.Point(613, 350);
            this.areaButton14.Name = "areaButton14";
            this.areaButton14.Size = new System.Drawing.Size(80, 80);
            this.areaButton14.TabIndex = 9;
            this.areaButton14.Text = "button2";
            this.areaButton14.UseVisualStyleBackColor = true;
            this.areaButton14.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // areaButton13
            // 
            this.areaButton13.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.fekete;
            this.areaButton13.Location = new System.Drawing.Point(527, 350);
            this.areaButton13.Name = "areaButton13";
            this.areaButton13.Size = new System.Drawing.Size(80, 80);
            this.areaButton13.TabIndex = 9;
            this.areaButton13.Text = "button2";
            this.areaButton13.UseVisualStyleBackColor = true;
            this.areaButton13.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // areaButton12
            // 
            this.areaButton12.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.fekete;
            this.areaButton12.Location = new System.Drawing.Point(441, 350);
            this.areaButton12.Name = "areaButton12";
            this.areaButton12.Size = new System.Drawing.Size(80, 80);
            this.areaButton12.TabIndex = 9;
            this.areaButton12.Text = "button2";
            this.areaButton12.UseVisualStyleBackColor = true;
            this.areaButton12.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // areaButton11
            // 
            this.areaButton11.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.fekete;
            this.areaButton11.Location = new System.Drawing.Point(355, 350);
            this.areaButton11.Name = "areaButton11";
            this.areaButton11.Size = new System.Drawing.Size(80, 80);
            this.areaButton11.TabIndex = 9;
            this.areaButton11.Text = "button2";
            this.areaButton11.UseVisualStyleBackColor = true;
            this.areaButton11.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // areaButton10
            // 
            this.areaButton10.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.fekete;
            this.areaButton10.Location = new System.Drawing.Point(698, 264);
            this.areaButton10.Name = "areaButton10";
            this.areaButton10.Size = new System.Drawing.Size(80, 80);
            this.areaButton10.TabIndex = 9;
            this.areaButton10.Text = "button2";
            this.areaButton10.UseVisualStyleBackColor = true;
            this.areaButton10.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // areaButton9
            // 
            this.areaButton9.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.fekete;
            this.areaButton9.Location = new System.Drawing.Point(612, 264);
            this.areaButton9.Name = "areaButton9";
            this.areaButton9.Size = new System.Drawing.Size(80, 80);
            this.areaButton9.TabIndex = 9;
            this.areaButton9.Text = "button2";
            this.areaButton9.UseVisualStyleBackColor = true;
            this.areaButton9.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // areaButton1x3
            // 
            this.areaButton1x3.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.fekete;
            this.areaButton1x3.Location = new System.Drawing.Point(526, 178);
            this.areaButton1x3.Name = "areaButton1x3";
            this.areaButton1x3.Size = new System.Drawing.Size(80, 80);
            this.areaButton1x3.TabIndex = 9;
            this.areaButton1x3.Text = "button2";
            this.areaButton1x3.UseVisualStyleBackColor = true;
            this.areaButton1x3.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // areaButton4
            // 
            this.areaButton4.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.fekete;
            this.areaButton4.Location = new System.Drawing.Point(612, 178);
            this.areaButton4.Name = "areaButton4";
            this.areaButton4.Size = new System.Drawing.Size(80, 80);
            this.areaButton4.TabIndex = 9;
            this.areaButton4.Text = "button2";
            this.areaButton4.UseVisualStyleBackColor = true;
            this.areaButton4.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // areaButton1x2
            // 
            this.areaButton1x2.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.fekete;
            this.areaButton1x2.ForeColor = System.Drawing.SystemColors.Control;
            this.areaButton1x2.Location = new System.Drawing.Point(440, 178);
            this.areaButton1x2.Name = "areaButton1x2";
            this.areaButton1x2.Size = new System.Drawing.Size(80, 80);
            this.areaButton1x2.TabIndex = 9;
            this.areaButton1x2.Text = "button2";
            this.areaButton1x2.UseVisualStyleBackColor = true;
            this.areaButton1x2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // areaButton1x1
            // 
            this.areaButton1x1.BackgroundImage = global::csharp0421AsztaliKilenc3.Properties.Resources.fekete;
            this.areaButton1x1.Location = new System.Drawing.Point(354, 178);
            this.areaButton1x1.Name = "areaButton1x1";
            this.areaButton1x1.Size = new System.Drawing.Size(80, 80);
            this.areaButton1x1.TabIndex = 9;
            this.areaButton1x1.Text = "button2";
            this.areaButton1x1.UseVisualStyleBackColor = true;
            this.areaButton1x1.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // richTextBoxDescription
            // 
            this.richTextBoxDescription.Location = new System.Drawing.Point(23, 317);
            this.richTextBoxDescription.Name = "richTextBoxDescription";
            this.richTextBoxDescription.ReadOnly = true;
            this.richTextBoxDescription.Size = new System.Drawing.Size(305, 225);
            this.richTextBoxDescription.TabIndex = 8;
            this.richTextBoxDescription.Text = "";
            // 
            // labelButton1
            // 
            this.labelButton1.AutoSize = true;
            this.labelButton1.Location = new System.Drawing.Point(373, 30);
            this.labelButton1.Name = "labelButton1";
            this.labelButton1.Size = new System.Drawing.Size(94, 20);
            this.labelButton1.TabIndex = 0;
            this.labelButton1.Text = "labelButton1";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(160, 51);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(152, 27);
            this.textBox2.TabIndex = 5;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(162, 103);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(94, 29);
            this.button3.TabIndex = 4;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 127);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "label3";
            // 
            // labelValue
            // 
            this.labelValue.AutoSize = true;
            this.labelValue.Location = new System.Drawing.Point(27, 73);
            this.labelValue.Name = "labelValue";
            this.labelValue.Size = new System.Drawing.Size(78, 20);
            this.labelValue.TabIndex = 1;
            this.labelValue.Text = "labelValue";
            // 
            // labelTerrain
            // 
            this.labelTerrain.AutoSize = true;
            this.labelTerrain.Location = new System.Drawing.Point(27, 27);
            this.labelTerrain.Name = "labelTerrain";
            this.labelTerrain.Size = new System.Drawing.Size(87, 20);
            this.labelTerrain.TabIndex = 0;
            this.labelTerrain.Text = "labelTerrain";
            // 
            // richTextBoxResponse
            // 
            this.richTextBoxResponse.Location = new System.Drawing.Point(23, 73);
            this.richTextBoxResponse.Name = "richTextBoxResponse";
            this.richTextBoxResponse.ReadOnly = true;
            this.richTextBoxResponse.Size = new System.Drawing.Size(281, 86);
            this.richTextBoxResponse.TabIndex = 7;
            this.richTextBoxResponse.Text = "";
            // 
            // aPanel2
            // 
            this.aPanel2.BackColor = System.Drawing.Color.Gainsboro;
            this.aPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.aPanel2.Location = new System.Drawing.Point(0, 0);
            this.aPanel2.Name = "aPanel2";
            this.aPanel2.Size = new System.Drawing.Size(1051, 662);
            this.aPanel2.TabIndex = 2;
            // 
            // aPanel3
            // 
            this.aPanel3.BackColor = System.Drawing.Color.Gainsboro;
            this.aPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.aPanel3.Location = new System.Drawing.Point(0, 0);
            this.aPanel3.Name = "aPanel3";
            this.aPanel3.Size = new System.Drawing.Size(1051, 662);
            this.aPanel3.TabIndex = 3;
            // 
            // aPanel4
            // 
            this.aPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.aPanel4.Location = new System.Drawing.Point(0, 0);
            this.aPanel4.Name = "aPanel4";
            this.aPanel4.Size = new System.Drawing.Size(1051, 662);
            this.aPanel4.TabIndex = 4;
            // 
            // aPanel0
            // 
            this.aPanel0.Controls.Add(this.textBox1);
            this.aPanel0.Controls.Add(this.richTextBoxResponse);
            this.aPanel0.Location = new System.Drawing.Point(0, 0);
            this.aPanel0.Name = "aPanel0";
            this.aPanel0.Size = new System.Drawing.Size(328, 173);
            this.aPanel0.TabIndex = 5;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(23, 23);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(281, 27);
            this.textBox1.TabIndex = 4;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // aPanelInfo
            // 
            this.aPanelInfo.Controls.Add(this.textBox2);
            this.aPanelInfo.Controls.Add(this.button3);
            this.aPanelInfo.Controls.Add(this.labelTerrain);
            this.aPanelInfo.Controls.Add(this.label3);
            this.aPanelInfo.Controls.Add(this.labelValue);
            this.aPanelInfo.Location = new System.Drawing.Point(727, 0);
            this.aPanelInfo.Name = "aPanelInfo";
            this.aPanelInfo.Size = new System.Drawing.Size(361, 159);
            this.aPanelInfo.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1051, 662);
            this.Controls.Add(this.aPanelInfo);
            this.Controls.Add(this.aPanel0);
            this.Controls.Add(this.aPanel1);
            this.Controls.Add(this.aPanel4);
            this.Controls.Add(this.aPanel3);
            this.Controls.Add(this.aPanel2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.aPanel1.ResumeLayout(false);
            this.aPanel1.PerformLayout();
            this.aPanel0.ResumeLayout(false);
            this.aPanel0.PerformLayout();
            this.aPanelInfo.ResumeLayout(false);
            this.aPanelInfo.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Panel aPanel1;
        private System.Windows.Forms.Label labelButton1;
        private System.Windows.Forms.Panel aPanel2;
        private System.Windows.Forms.Panel aPanel3;
        private System.Windows.Forms.Panel aPanel4;
        private System.Windows.Forms.Panel aPanel0;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.RichTextBox richTextBoxResponse;
        private System.Windows.Forms.RichTextBox richTextBoxDescription;
        private System.Windows.Forms.Button areaButton1x1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelValue;
        private System.Windows.Forms.Label labelTerrain;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Panel aPanelInfo;
        private System.Windows.Forms.Button buttonNyugat;
        private System.Windows.Forms.Button buttonDel;
        private System.Windows.Forms.Button buttonEszak;
        private System.Windows.Forms.Button buttonKelet;
        private System.Windows.Forms.RichTextBox labelRichTextBox1;
        private System.Windows.Forms.RichTextBox labelTextBox1;
        private System.Windows.Forms.Button areaButton8;
        private System.Windows.Forms.Button areaButton7;
        private System.Windows.Forms.Button areaButton6;
        private System.Windows.Forms.Button areaButton5;
        private System.Windows.Forms.Button areaButton16;
        private System.Windows.Forms.Button areaButton15;
        private System.Windows.Forms.Button areaButton14;
        private System.Windows.Forms.Button areaButton13;
        private System.Windows.Forms.Button areaButton12;
        private System.Windows.Forms.Button areaButton11;
        private System.Windows.Forms.Button areaButton10;
        private System.Windows.Forms.Button areaButton9;
        private System.Windows.Forms.Button areaButton1x3;
        private System.Windows.Forms.Button areaButton4;
        private System.Windows.Forms.Button areaButton1x2;
        private System.Windows.Forms.Button areaButton20;
        private System.Windows.Forms.Button areaButton19;
        private System.Windows.Forms.Button areaButton18;
        private System.Windows.Forms.Button areaButton17;
        private System.Windows.Forms.Button areaButton25;
        private System.Windows.Forms.Button areaButton24;
        private System.Windows.Forms.Button areaButton23;
        private System.Windows.Forms.Button areaButton22;
        private System.Windows.Forms.Button areaButton21;
    }
}

